macroScript mrt_SmartDimension
category:"mrtTools"
tooltip:"Smart Dimension"
buttonText:"Smart Dimension"
icon:#("Helpers", 1)
(
	local mrt_SmartDim_Main, mrt_SmartDim_TopBar, mrt_SmartDim_BBox, mrt_SmartDim_Measure
	local roll_smart_objects_distance, mrt_SmartDim_Angle, roll_area_peri_tool
	local mrt_SmartDim_About, mrt_SmartDim_Logic
	global cb_SmartDimAutoSelect
	local mrt_SmartDim_isSelecting = false
	
	local iniFile = (getDir #plugcfg) + "\\mrt_smart_dim_layout.ini"

	callbacks.removeScripts id:#SmartDimAutoSelect

	-- =========================================================================
	-- CUSTOM ATTRIBUTES DEFINITION
	-- =========================================================================
	local mrt_SmartDimData_CA = attributes "SmartDimData"
	(
		parameters main rollout:params
		(
			IsSmartDim type:#boolean default:false
			IsSmartObjDim type:#boolean default:false
			IsAngleDim type:#boolean default:false
			IsAreaDim type:#boolean default:false

			Dim_Type type:#string default:""
			Dim_PtA type:#point3 default:[0,0,0]
			Dim_PtB type:#point3 default:[0,0,0]
			Dim_OutDir type:#point3 default:[0,-1,0]
			Dim_RawDist type:#float default:0.0
			Dim_ParentHandle type:#string default:""
			Dim_ParentHandle2 type:#string default:""
			Dim_UnitIdx type:#integer default:1
			
			Dim_ArrowS type:#float default:1.0
			Dim_TextS type:#float default:1.0
			Dim_OffsetDist type:#float default:1.0
			Dim_ArrType type:#integer default:3
			Dim_TxtOff type:#float default:0.0
			Dim_LineCol type:#color default:white
			Dim_TextCol type:#color default:white
			Dim_TextFlipped type:#boolean default:false

			Ang_RawP1 type:#point3 default:[0,0,0]
			Ang_RawP2 type:#point3 default:[0,0,0]
			Ang_RawP3 type:#point3 default:[0,0,0]
			Ang_IsFirst type:#boolean default:true
			Ang_IsLast type:#boolean default:true
		)
		rollout params "Smart Dimension Data" (
			label lbl_info "Do not modify manually." align:#center
		)
	)

	-- =========================================================================
	-- CORE LOGIC STRUCT
	-- =========================================================================
	struct mrt_SmartDimLogic_Struct
	(
		fn hasCA obj propName = (
			(isProperty obj propName)
		),

		fn getUnitFactor uType = (
			case uType of (
				#Inches: 1.0
				#Feet: 12.0
				#Miles: 63360.0
				#Millimeters: 0.0393700787
				#Centimeters: 0.393700787
				#Meters: 39.3700787
				#Kilometers: 39370.0787
				default: 1.0
			)
		),

		fn getDisplayUnitData = (
			local sysScale = getUnitFactor units.SystemType
			local dispScale = 1.0
			local dStr = ""

			if units.DisplayType == #Metric then (
				dispScale = getUnitFactor units.MetricType
				case units.MetricType of (
					#Millimeters: dStr = "mm"
					#Centimeters: dStr = "cm"
					#Meters: dStr = "m"
					#Kilometers: dStr = "km"
				)
			) else if units.DisplayType == #US then (
				dispScale = getUnitFactor units.USType
				case units.USType of (
					#Frac_In: dStr = "in"
					#Dec_In: dStr = "in"
					#Frac_Ft: dStr = "ft"
					#Dec_Ft: dStr = "ft"
					#Ft_Frac_In: dStr = "in"
					#Ft_Dec_In: dStr = "in"
					default: dStr = "in"
				)
			) else (
				dispScale = sysScale
				dStr = ""
			)

			return #( (sysScale / dispScale), dStr )
		),
		
		fn getDynamicUnitString = (
			local dData = getDisplayUnitData()
			local sysUnit = dData[2]
			if sysUnit == "" do sysUnit = "Generic"
			return sysUnit
		),

		fn formatValue dist uIdx = (
			local sysScale = getUnitFactor units.SystemType
			local outVal = dist * sysScale
			local uStr = ""
			
			if uIdx == 1 then (
				local dData = getDisplayUnitData()
				outVal = dist * dData[1]
				uStr = dData[2]
			) else if uIdx == 2 then ( outVal = outVal / 0.0393700787; uStr = "mm" )
			else if uIdx == 3 then ( outVal = outVal / 0.393700787; uStr = "cm" )
			else if uIdx == 4 then ( outVal = outVal / 39.3700787; uStr = "m" )
			else if uIdx == 5 then ( outVal = outVal; uStr = "in" )
			else if uIdx == 6 then ( outVal = outVal / 12.0; uStr = "ft" )
			
			return (formattedPrint outVal format:".2f") + " " + uStr
		),

		fn getObjThickness obj outD = (
			if not isValidNode obj do return 0.0
			local corners = #()
			local bbLocal = nodeLocalBoundingBox obj
			local bMinL = bbLocal[1]
			local bMaxL = bbLocal[2]
			local tm = obj.transform

			append corners ([bMinL.x, bMinL.y, bMinL.z] * tm)
			append corners ([bMaxL.x, bMinL.y, bMinL.z] * tm)
			append corners ([bMinL.x, bMaxL.y, bMinL.z] * tm)
			append corners ([bMaxL.x, bMaxL.y, bMinL.z] * tm)
			append corners ([bMinL.x, bMinL.y, bMaxL.z] * tm)
			append corners ([bMaxL.x, bMinL.y, bMaxL.z] * tm)
			append corners ([bMinL.x, bMaxL.y, bMaxL.z] * tm)
			append corners ([bMaxL.x, bMaxL.y, bMaxL.z] * tm)

			local maxProj = -1e9
			local minProj = 1e9
			for c in corners do (
				local proj = dot c outD
				if proj > maxProj do maxProj = proj
				if proj < minProj do minProj = proj
			)
			return abs(maxProj - minProj)
		),

		fn buildTextMatrix linePtA linePtB outDir textPos textFlipped:false = (
			local lineDir = normalize (linePtB - linePtA)
			if length (linePtB - linePtA) < 0.001 do lineDir = [1,0,0]
			
			local r, u, n
			
			if abs(lineDir.z) > 0.7 then (
				r = [1, 0, 0]
				u = [0, 0, 1]
				n = [0, -1, 0]
				
				if textFlipped do (
					r = -r
					n = -n
				)
			) else (
				local oDir = [outDir.x, outDir.y, 0]
				if length oDir < 0.001 then oDir = [0, -1, 0] else oDir = normalize oDir
				
				u = -oDir
				n = [0, 0, 1]
				r = normalize (cross u n)

				if textFlipped do (
					r = -r
					u = -u
				)
			)
			
			return (matrix3 r u n textPos)
		),
		
		fn getOrCreateMaterial matColor prefix = (
			local rHex = bit.intAsHex (matColor.r as integer)
			local gHex = bit.intAsHex (matColor.g as integer)
			local bHex = bit.intAsHex (matColor.b as integer)
			local matName = prefix + "_" + rHex + gHex + bHex
			local m = sceneMaterials[matName]
			if m == undefined do (
				m = StandardMaterial name:matName diffuse:matColor selfIllumAmount:100
			)
			return m
		),

		fn createArrowMesh p tailDir normalVec size type col = (
			if type == 4 do return undefined
			local rightV = normalize (cross tailDir normalVec)
			local arr
			
			if type == 3 then (
				local w = size * 0.35
				local v1 = p
				local v2 = p + (tailDir * size) + (rightV * w)
				local v3 = p + (tailDir * size) - (rightV * w)
				arr = mesh vertices:#(v1, v2, v3) faces:#([1,2,3], [1,3,2])
			) else if type == 2 then (
				local radius = size * 0.35
				local segs = 16
				local verts = #()
				local faces = #()
				append verts p
				for i = 0 to (segs - 1) do (
					local ang = (i as float / segs) * 360.0
					append verts (p + (tailDir * (cos ang) * radius) + (rightV * (sin ang) * radius))
				)
				for i = 1 to segs do (
					local nextI = if i == segs then 2 else (i + 2)
					append faces [1, i+1, nextI]
					append faces [1, nextI, i+1]
				)
				arr = mesh vertices:verts faces:faces
			) else if type == 1 then (
				local w = size * 0.4
				local v1 = p + (tailDir * size) + (rightV * w)
				local v2 = p
				local v3 = p + (tailDir * size) - (rightV * w)
				local sp = SplineShape pos:p
				local idx = addNewSpline sp
				addKnot sp idx #corner #line v1
				addKnot sp idx #corner #line v2
				addKnot sp idx #corner #line v3
				if isProperty sp #render_renderable do sp.render_renderable = true
				if isProperty sp #render_displayInVP do sp.render_displayInVP = true
				if isProperty sp #render_thickness do sp.render_thickness = size * 0.08
				arr = sp
			)
			
			if arr != undefined do (
				arr.name = uniqueName "SmartDim_Marker"
				arr.wirecolor = col
				arr.material = getOrCreateMaterial col "Marker_Mat"
			)
			return arr
		),

		fn createSmartDimLine ptA ptB outDir rawDist arrowS textS offsetDist lCol tCol dimType pHandle uIdx arrType txtOff textFlipped:false = (
			local textMat = getOrCreateMaterial tCol "SmartDim_TextMat"
			
			local startPt = ptA + (outDir * offsetDist)
			local endPt = ptB + (outDir * offsetDist)
			
			local dimLine = SplineShape pos:[0,0,0]
			dimLine.name = uniqueName "SmartDim_Line"
			dimLine.wirecolor = lCol

			local lineDir = normalize (endPt - startPt)
			if length (endPt - startPt) < 0.001 do lineDir = [1,0,0]
			
			local tNorm = normalize (cross lineDir outDir)
			if length tNorm < 0.001 do tNorm = [0,0,1]
			
			local dir1 = lineDir
			local dir2 = -lineDir

			local reqSpace = (arrowS * 2.5)
			local isTightSpace = rawDist < reqSpace

			local lineStart, lineEnd
			local a1, a2
			
			local cutS = if arrType == 2 then (arrowS * 0.35) else if arrType == 3 then arrowS else 0.0

			if not isTightSpace then (
				a1 = createArrowMesh startPt dir1 tNorm arrowS arrType lCol
				a2 = createArrowMesh endPt dir2 tNorm arrowS arrType lCol
				
				lineStart = startPt + (dir1 * cutS)
				lineEnd = endPt + (dir2 * cutS)
			) else (
				a1 = createArrowMesh startPt dir2 tNorm arrowS arrType lCol
				a2 = createArrowMesh endPt dir1 tNorm arrowS arrType lCol
				
				local outDistArr = arrowS * 2.0
				lineStart = startPt + (dir2 * outDistArr)
				lineEnd = endPt + (dir1 * outDistArr)
			)

			if not isTightSpace then (
				local s1 = addNewSpline dimLine
				addKnot dimLine s1 #corner #line lineStart
				addKnot dimLine s1 #corner #line lineEnd
			) else (
				local s1 = addNewSpline dimLine
				addKnot dimLine s1 #corner #line startPt
				addKnot dimLine s1 #corner #line lineStart

				local s1_2 = addNewSpline dimLine
				addKnot dimLine s1_2 #corner #line endPt
				addKnot dimLine s1_2 #corner #line lineEnd
			)

			if arrType != 4 do (
				local gap = arrowS * 0.5
				local p1_extObj = ptA + (outDir * gap)
				local p1_extEnd = startPt + (outDir * (arrowS * 0.6))
				
				local s2 = addNewSpline dimLine
				addKnot dimLine s2 #corner #line p1_extObj
				addKnot dimLine s2 #corner #line p1_extEnd

				local p2_extObj = ptB + (outDir * gap)
				local p2_extEnd = endPt + (outDir * (arrowS * 0.6))

				local s3 = addNewSpline dimLine
				addKnot dimLine s3 #corner #line p2_extObj
				addKnot dimLine s3 #corner #line p2_extEnd
			)

			updateShape dimLine

			local valText = formatValue rawDist uIdx
			local txt = Text text:valText size:textS
			txt.name = uniqueName "SmartDim_Text"
			txt.wirecolor = tCol
			txt.material = textMat
			
			local midPos = (startPt + endPt) / 2.0
			txt.alignment = 2
			
			txt.transform = buildTextMatrix ptA ptB outDir midPos textFlipped:textFlipped
			
			local isZAxis = (abs(lineDir.z) > 0.7)
			local baseTextGap = if isZAxis then ((arrowS * 1.5) + (textS * 2.0)) else ((arrowS * 0.7) + (textS * 1.1))
			txt.pos += outDir * (baseTextGap + txtOff)
			
			local groupItems = #(dimLine, txt)
			if a1 != undefined do append groupItems a1
			if a2 != undefined do append groupItems a2
			
			local dimGroup = group groupItems name:(uniqueName "SmartDim_Group") select:false
			
			custAttributes.add dimGroup mrt_SmartDimData_CA
			dimGroup.IsSmartDim = true
			dimGroup.Dim_Type = dimType
			dimGroup.Dim_PtA = ptA
			dimGroup.Dim_PtB = ptB
			dimGroup.Dim_OutDir = outDir
			dimGroup.Dim_RawDist = rawDist
			dimGroup.Dim_ParentHandle = (if pHandle != undefined then pHandle as string else "")
			dimGroup.Dim_UnitIdx = uIdx
			dimGroup.Dim_ArrowS = arrowS
			dimGroup.Dim_TextS = textS
			dimGroup.Dim_OffsetDist = offsetDist
			dimGroup.Dim_ArrType = arrType
			dimGroup.Dim_TxtOff = txtOff
			dimGroup.Dim_LineCol = lCol
			dimGroup.Dim_TextCol = tCol
			dimGroup.Dim_TextFlipped = textFlipped

			if pHandle != undefined and pHandle != 0 do (
				local parentObj = maxOps.getNodeByHandle (pHandle as integer)
				if isValidNode parentObj do dimGroup.parent = parentObj
			)
			
			return dimGroup
		),

		fn checkBBoxInterference objList = (
			for obj in objList where isValidNode obj do (
				if isGroupHead obj and hasCA obj #IsSmartDim and obj.IsSmartDim and obj.Dim_Type == "Smart" do return true
				local hStr = obj.handle as string
				for o in objects where isValidNode o and isGroupHead o and hasCA o #IsSmartDim and o.IsSmartDim and o.Dim_Type == "Smart" do (
					if o.Dim_ParentHandle == hStr do return true
				)
			)
			return false
		),

		fn syncUIToDim grp = (
			if isValidNode grp and hasCA grp #IsSmartDim and grp.IsSmartDim do (
				local dType = grp.Dim_Type
				local c_arrow = grp.Dim_ArrowS
				local c_text = grp.Dim_TextS
				local c_offset = grp.Dim_OffsetDist
				local c_arrType = grp.Dim_ArrType
				local c_txtOff = grp.Dim_TxtOff
				local c_lcol = grp.Dim_LineCol
				local c_tcol = grp.Dim_TextCol
				local c_uidx = grp.Dim_UnitIdx
				
				try (
					if dType == "Smart" then (
						mrt_SmartDim_BBox.spn_s_arrow.value = c_arrow
						mrt_SmartDim_BBox.spn_s_text.value = c_text
						mrt_SmartDim_BBox.spn_s_offset.value = c_offset
						mrt_SmartDim_BBox.ddl_s_arrTyp.selection = c_arrType
						mrt_SmartDim_BBox.spn_s_txtOff.value = c_txtOff
						mrt_SmartDim_BBox.cp_s_line.color = c_lcol
						mrt_SmartDim_BBox.cp_s_text.color = c_tcol
						mrt_SmartDim_BBox.ddl_s_units.selection = c_uidx
					) else if dType == "Measure" then (
						mrt_SmartDim_Measure.spn_m_arrow.value = c_arrow
						mrt_SmartDim_Measure.spn_m_text.value = c_text
						mrt_SmartDim_Measure.spn_m_offset.value = c_offset
						mrt_SmartDim_Measure.ddl_m_arrTyp.selection = c_arrType
						mrt_SmartDim_Measure.spn_m_txtOff.value = c_txtOff
						mrt_SmartDim_Measure.cp_m_line.color = c_lcol
						mrt_SmartDim_Measure.cp_m_text.color = c_tcol
						mrt_SmartDim_Measure.ddl_m_units.selection = c_uidx
					)
				) catch()
			)
		),

		fn updateLiveDims mode = (
			local selArray = for o in selection where isValidNode o collect o
			local targetDims = #()
			local reqType = if mode == #bbox then "Smart" else if mode == #measure then "Measure" else undefined
			
			for obj in selArray where isValidNode obj do (
				if isGroupHead obj and hasCA obj #IsSmartDim and obj.IsSmartDim then (
					if reqType == undefined or obj.Dim_Type == reqType do appendIfUnique targetDims obj
				) else (
					local hStr = obj.handle as string
					for o in objects where (isValidNode o and isGroupHead o and hasCA o #IsSmartDim and o.IsSmartDim) do (
						if o.Dim_ParentHandle == hStr and (reqType == undefined or o.Dim_Type == reqType) do appendIfUnique targetDims o
					)
				)
			)

			if targetDims.count == 0 do (
				for o in objects where (isValidNode o and isGroupHead o and hasCA o #IsSmartDim and o.IsSmartDim) do (
					if reqType == undefined or o.Dim_Type == reqType do appendIfUnique targetDims o
				)
			)
			if targetDims.count == 0 do return false

			local newSel = #()
			mrt_SmartDim_isSelecting = true
			
			with undo off (
				with redraw off (
					for grp in targetDims where isValidNode grp do (
						if hasCA grp #IsSmartDim and grp.IsSmartDim do (
							local dType = grp.Dim_Type
							local pA = grp.Dim_PtA
							local pB = grp.Dim_PtB
							local dOut = grp.Dim_OutDir
							local rDist = grp.Dim_RawDist
							local pHandle = if grp.Dim_ParentHandle != "" then (grp.Dim_ParentHandle as integer) else undefined
							local c_tFlipped = grp.Dim_TextFlipped

							local c_arrow = grp.Dim_ArrowS
							local c_text = grp.Dim_TextS
							local c_offset = grp.Dim_OffsetDist
							local c_arrTyp = grp.Dim_ArrType
							local c_txtOff = grp.Dim_TxtOff
							local c_lcol = grp.Dim_LineCol
							local c_tcol = grp.Dim_TextCol
							local c_uidx = grp.Dim_UnitIdx

							if mode == #bbox and dType == "Smart" then (
								c_arrow = mrt_SmartDim_BBox.spn_s_arrow.value
								c_text = mrt_SmartDim_BBox.spn_s_text.value
								c_offset = mrt_SmartDim_BBox.spn_s_offset.value
								c_arrTyp = mrt_SmartDim_BBox.ddl_s_arrTyp.selection
								c_txtOff = mrt_SmartDim_BBox.spn_s_txtOff.value
								c_lcol = mrt_SmartDim_BBox.cp_s_line.color
								c_tcol = mrt_SmartDim_BBox.cp_s_text.color
							) else if mode == #measure and dType == "Measure" then (
								c_arrow = mrt_SmartDim_Measure.spn_m_arrow.value
								c_text = mrt_SmartDim_Measure.spn_m_text.value
								c_offset = mrt_SmartDim_Measure.spn_m_offset.value
								c_arrTyp = mrt_SmartDim_Measure.ddl_m_arrTyp.selection
								c_txtOff = mrt_SmartDim_Measure.spn_m_txtOff.value
								c_lcol = mrt_SmartDim_Measure.cp_m_line.color
								c_tcol = mrt_SmartDim_Measure.cp_m_text.color
							) else if mode == #units then (
								if dType == "Smart" then c_uidx = mrt_SmartDim_BBox.ddl_s_units.selection
								else if dType == "Measure" then c_uidx = mrt_SmartDim_Measure.ddl_m_units.selection
							)

							local children = for c in grp.children where isValidNode c collect c
							for c in children where isValidNode c do delete c
							if isValidNode grp do delete grp

							local newG = createSmartDimLine pA pB dOut rDist c_arrow c_text c_offset c_lcol c_tcol dType pHandle c_uidx c_arrTyp c_txtOff textFlipped:c_tFlipped
							append newSel newG
						)
					)
					if newSel.count > 0 do select newSel
				)
			)
			mrt_SmartDim_isSelecting = false
			redrawViews()
		),

		fn flipSelectedDims = (
			local selArray = for o in selection where isValidNode o collect o
			local targetDims = #()
			for obj in selArray where isValidNode obj do (
				if isGroupHead obj and hasCA obj #IsSmartDim and obj.IsSmartDim then (
					appendIfUnique targetDims obj
				) else (
					local hStr = obj.handle as string
					for o in objects where (isValidNode o and isGroupHead o and hasCA o #IsSmartDim and o.IsSmartDim) do (
						if o.Dim_ParentHandle == hStr do appendIfUnique targetDims o
					)
				)
			)

			local didFlip = false
			for grp in targetDims where isValidNode grp do (
				if hasCA grp #IsSmartDim and grp.IsSmartDim do (
					local outD = grp.Dim_OutDir
					local pA = grp.Dim_PtA
					local pB = grp.Dim_PtB
					local pHandleStr = grp.Dim_ParentHandle
					local pHandle = if pHandleStr != "" then (pHandleStr as integer) else undefined
					local isFlippedText = grp.Dim_TextFlipped

					if outD != undefined and pA != undefined and pB != undefined do (
						local newPA, newPB, newOutD
						local newTFlipped = isFlippedText
						local lineDir = normalize (pB - pA)
						local dType = grp.Dim_Type
						
						if abs(lineDir.z) > 0.7 then (
							local parentObj = if pHandle != undefined then maxOps.getNodeByHandle pHandle else undefined
							if isValidNode parentObj then (
								local dy = abs(parentObj.max.y - parentObj.min.y)
								local dirY = if pA.y < parentObj.center.y then 1.0 else -1.0
								newPA = pA + [0, dy * dirY, 0]
								newPB = pB + [0, dy * dirY, 0]
							) else (
								newPA = pA
								newPB = pB
							)
							newOutD = outD
							newTFlipped = not isFlippedText
						) else if dType == "Smart" and abs(lineDir.y) > 0.7 then (
							newPA = pA
							newPB = pB
							newOutD = outD
							newTFlipped = isFlippedText
						) else (
							local thick = 0.0
							if pHandle != undefined do (
								local parentObj = maxOps.getNodeByHandle pHandle
								if isValidNode parentObj do (
									thick = getObjThickness parentObj outD
								)
							)
							newPA = pA - (outD * thick)
							newPB = pB - (outD * thick)
							newOutD = -outD
							newTFlipped = isFlippedText
						)

						grp.Dim_PtA = newPA
						grp.Dim_PtB = newPB
						grp.Dim_OutDir = newOutD
						grp.Dim_TextFlipped = newTFlipped
						didFlip = true
					)
				)
			)
			if didFlip do updateLiveDims #refresh
		),
		
		fn clearSectionDims sectionName = (
			local selObjs = for o in selection collect o
			local selHandles = for o in selObjs collect (o.handle as string)
			local toDelete = #()
			
			for o in objects where (isValidNode o and isGroupHead o and isProperty o #IsSmartDim) do (
				local isTarget = false
				case sectionName of (
					"BBox": if o.IsSmartDim and o.Dim_Type == "Smart" do isTarget = true
					"Measure": if o.IsSmartDim and o.Dim_Type == "Measure" do isTarget = true
					"SmartObj": if o.IsSmartObjDim do isTarget = true
					"Angle": if o.IsAngleDim do isTarget = true
					"Area": if o.IsAreaDim do isTarget = true
				)
				
				if isTarget do (
					if (findItem selObjs o) > 0 then (
						appendIfUnique toDelete o
					) else (
						local pHandle1 = o.Dim_ParentHandle
						local pHandle2 = o.Dim_ParentHandle2
						
						if pHandle1 != "" and (findItem selHandles pHandle1) > 0 do appendIfUnique toDelete o
						if pHandle2 != "" and (findItem selHandles pHandle2) > 0 do appendIfUnique toDelete o
					)
				)
			)
			
			for grp in toDelete where isValidNode grp do (
				local children = for c in grp.children where isValidNode c collect c
				for c in children where isValidNode c do delete c
				if isValidNode grp do delete grp
			)
		)
	)
	
	mrt_SmartDim_Logic = mrt_SmartDimLogic_Struct()

	-- =========================================================================
	-- CALLBACK DEFINITION
	-- =========================================================================
	fn cb_SmartDimAutoSelect = (
		if mrt_SmartDim_isSelecting do return false
		if mrt_SmartDim_Main != undefined and mrt_SmartDim_Main.open do (
			mrt_SmartDim_isSelecting = true
			
			local hasNonDim = false
			local selHandles = #()
			local dimGroups = #()
			
			for o in selection where isValidNode o do (
				if not (isProperty o #IsSmartDim and o.IsSmartDim) then (
					hasNonDim = true
					append selHandles (o.handle as string)
				) else (
					append dimGroups o
				)
			)
			
			if hasNonDim then (
				local toSelect = #()
				for o in objects where isValidNode o and isProperty o #IsSmartDim and o.IsSmartDim do (
					local pHandle = o.Dim_ParentHandle
					if pHandle != "" and (findItem selHandles pHandle) > 0 do (
						append toSelect o
					)
				)
				if toSelect.count > 0 do selectMore toSelect
			) else if dimGroups.count > 0 do (
				mrt_SmartDim_Logic.syncUIToDim dimGroups[1]
			)
			
			mrt_SmartDim_isSelecting = false
		)
	)

	-- =========================================================================
	-- ROLLOUT 0: QUICK ACCESS BAR
	-- =========================================================================
	rollout mrt_SmartDim_TopBar "Quick Access" height:105
	(
		button btn_Q_B "Auto Dimension" width:100 height:24 pos:[12,10]
		button btn_Q_SD "Objects Distance" width:100 height:24 pos:[118,10]
		
		button btn_Q_MD "Length (2p)" width:100 height:24 pos:[12,40]
		button btn_Q_A "Angle" width:100 height:24 pos:[118,40]
		
		button btn_Q_AP "Area & perimeter" width:206 height:24 pos:[12,70]

		on btn_Q_B pressed do (
			mrt_SmartDim_BBox.open = true
			mrt_SmartDim_BBox.btn_gen.pressed()
		)
		on btn_Q_MD pressed do (
			mrt_SmartDim_Measure.open = true
			mrt_SmartDim_Measure.chk_measureDist.state = true
			mrt_SmartDim_Measure.chk_measureDist.changed true
		)
		on btn_Q_SD pressed do (
			roll_smart_objects_distance.open = true
			roll_smart_objects_distance.btnCalculate.pressed()
		)
		on btn_Q_A pressed do (
			mrt_SmartDim_Angle.open = true
			mrt_SmartDim_Angle.btn_start.state = true
			mrt_SmartDim_Angle.btn_start.changed true
		)
		on btn_Q_AP pressed do (
			roll_area_peri_tool.open = true
			roll_area_peri_tool.btn_start.state = true
			roll_area_peri_tool.btn_start.changed true
		)
	)

	-- =========================================================================
	-- ROLLOUT 1: AUTO BOUNDING BOX
	-- =========================================================================
	rollout mrt_SmartDim_BBox "Auto Bounding Box" height:285 rolledUp:true
	(
		button btn_gen "Bounding Box" pos:[12,10] width:100 height:24
		button btn_clr "Clear" pos:[118,10] width:100 height:24
		
		label lbl_s_text "Text Size:" pos:[15,44] width:75 height:18
		spinner spn_s_text "" pos:[95,43] width:125 fieldwidth:65 range:[0.01, 10000.0, 5.0] type:#float
		
		label lbl_s_arrow "Marker Size:" pos:[15,69] width:75 height:18
		spinner spn_s_arrow "" pos:[95,68] width:125 fieldwidth:65 range:[0.01, 10000.0, 4.0] type:#float
		
		label lbl_s_offset "Offset Dist:" pos:[15,94] width:75 height:18
		spinner spn_s_offset "" pos:[95,93] width:125 fieldwidth:65 range:[0.0, 10000.0, 10.0] type:#float
		
		label lbl_s_txtOff "Text Offset:" pos:[15,119] width:75 height:18
		spinner spn_s_txtOff "" pos:[95,118] width:125 fieldwidth:65 range:[-1000.0, 1000.0, 0.0] type:#float
		
		label lbl_s_arrTyp "Marker Type:" pos:[15,144] width:75 height:18
		dropdownlist ddl_s_arrTyp "" pos:[95,142] width:125 items:#("Open Arrow", "Solid Circle", "Filled Triangle", "None") selection:3
		
		colorpicker cp_s_text "Text:" pos:[15,170] width:95 height:22 color:(color 255 255 255)
		colorpicker cp_s_line "Line:" pos:[123,170] width:95 height:22 color:(color 255 255 255)
		
		button btn_flip_s "Flip Side" pos:[12,202] width:206 height:25
		dropdownlist ddl_s_units "Units:" pos:[12,235] width:206 items:#()

		on mrt_SmartDim_BBox open do (
			local dynUnit = mrt_SmartDim_Logic.getDynamicUnitString()
			ddl_s_units.items = #(dynUnit, "mm", "cm", "m", "inch", "feet")
		)

		on ddl_s_units selected idx do mrt_SmartDim_Logic.updateLiveDims #units
		on spn_s_text changed val do mrt_SmartDim_Logic.updateLiveDims #bbox
		on spn_s_arrow changed val do mrt_SmartDim_Logic.updateLiveDims #bbox
		on spn_s_offset changed val do mrt_SmartDim_Logic.updateLiveDims #bbox
		on spn_s_txtOff changed val do mrt_SmartDim_Logic.updateLiveDims #bbox
		on ddl_s_arrTyp selected idx do mrt_SmartDim_Logic.updateLiveDims #bbox
		on cp_s_text changed col do mrt_SmartDim_Logic.updateLiveDims #bbox
		on cp_s_line changed col do mrt_SmartDim_Logic.updateLiveDims #bbox
		on btn_flip_s pressed do mrt_SmartDim_Logic.flipSelectedDims()

		on btn_gen pressed do (
			if selection.count == 0 do (
				messageBox "Please select one or more objects first." title:"Smart Dimensions"
				return false
			)
			local createdDims = #()
			mrt_SmartDim_isSelecting = true
			local targetObjs = for o in selection where isValidNode o collect o
			
			undo "Auto Bounding Box" on (
				for obj in targetObjs where isValidNode obj do (
					if isGroupHead obj and isProperty obj #IsSmartDim and obj.IsSmartDim do continue
					if obj.parent != undefined and isGroupHead obj.parent and isProperty obj.parent #IsSmartDim and obj.parent.IsSmartDim do continue

					local bMin = obj.min
					local bMax = obj.max
					
					local dx = abs(bMax.x - bMin.x)
					local dy = abs(bMax.y - bMin.y)
					local dz = abs(bMax.z - bMin.z)
					
					local maxDim = amax #(dx, dy, dz)
					if maxDim == 0 do continue
					
					local bText = spn_s_text.value
					local bArrow = spn_s_arrow.value
					local bOffset = spn_s_offset.value
					local arrTyp = ddl_s_arrTyp.selection
					local txtOff = spn_s_txtOff.value
					local uIdx = if ddl_s_units.selection > 0 then ddl_s_units.selection else 1
					
					if dx > 0 do (
						local ptA_X = [bMin.x, bMin.y, bMin.z]
						local ptB_X = [bMax.x, bMin.y, bMin.z]
						local dimX = mrt_SmartDim_Logic.createSmartDimLine ptA_X ptB_X [0,-1,0] dx bArrow bText bOffset cp_s_line.color cp_s_text.color "Smart" obj.handle uIdx arrTyp txtOff
						append createdDims dimX
					)
					
					if dy > 0 do (
						local ptA_Y = [bMax.x, bMin.y, bMin.z]
						local ptB_Y = [bMax.x, bMax.y, bMin.z]
						local dimY = mrt_SmartDim_Logic.createSmartDimLine ptA_Y ptB_Y [1,0,0] dy bArrow bText bOffset cp_s_line.color cp_s_text.color "Smart" obj.handle uIdx arrTyp txtOff
						append createdDims dimY
					)
					
					if dz > 0 do (
						local ptA_Z = [bMax.x, bMin.y, bMin.z]
						local ptB_Z = [bMax.x, bMin.y, bMax.z]
						local outZ = [1, 0, 0]
						local dimZ = mrt_SmartDim_Logic.createSmartDimLine ptA_Z ptB_Z outZ dz bArrow bText bOffset cp_s_line.color cp_s_text.color "Smart" obj.handle uIdx arrTyp txtOff
						append createdDims dimZ
					)
				)
				if createdDims.count > 0 do select createdDims
			)
			mrt_SmartDim_isSelecting = false
		)

		on btn_clr pressed do undo "Clear Bounding Box" on (
			mrt_SmartDim_Logic.clearSectionDims "BBox"
		)
	)

	-- =========================================================================
	-- ROLLOUT 2: MEASURE DISTANCE
	-- =========================================================================
	rollout mrt_SmartDim_Measure "Measure Distance" height:285 rolledUp:true
	(
		checkbutton chk_measureDist "Measure" pos:[10,10] width:60 height:24 highlightColor:(color 0 150 255)
		edittext txt_distVal "" pos:[75,12] width:70 height:20 readonly:true
		button btn_copy "C" pos:[150,10] width:22 height:24 tooltip:"Copy Value"
		button btn_clr "Clear" pos:[176,10] width:45 height:24
		
		label lbl_m_text "Text Size:" pos:[15,44] width:75 height:18
		spinner spn_m_text "" pos:[95,43] width:125 fieldwidth:65 range:[0.01, 10000.0, 5.0] type:#float
		
		label lbl_m_arrow "Marker Size:" pos:[15,69] width:75 height:18
		spinner spn_m_arrow "" pos:[95,68] width:125 fieldwidth:65 range:[0.01, 10000.0, 4.0] type:#float
		
		label lbl_m_offset "Offset Dist:" pos:[15,94] width:75 height:18
		spinner spn_m_offset "" pos:[95,93] width:125 fieldwidth:65 range:[0.0, 10000.0, 10.0] type:#float
		
		label lbl_m_txtOff "Text Offset:" pos:[15,119] width:75 height:18
		spinner spn_m_txtOff "" pos:[95,118] width:125 fieldwidth:65 range:[-1000.0, 1000.0, 0.0] type:#float
		
		label lbl_m_arrTyp "Marker Type:" pos:[15,144] width:75 height:18
		dropdownlist ddl_m_arrTyp "" pos:[95,142] width:125 items:#("Open Arrow", "Solid Circle", "Filled Triangle", "None") selection:3
		
		colorpicker cp_m_text "Text:" pos:[15,170] width:95 height:22 color:(color 255 255 255)
		colorpicker cp_m_line "Line:" pos:[123,170] width:95 height:22 color:(color 255 255 255)
		
		button btn_flip_m "Flip Side" pos:[12,202] width:206 height:25
		dropdownlist ddl_m_units "Units:" pos:[12,235] width:206 items:#()

		on mrt_SmartDim_Measure open do (
			local dynUnit = mrt_SmartDim_Logic.getDynamicUnitString()
			ddl_m_units.items = #(dynUnit, "mm", "cm", "m", "inch", "feet")
		)

		on ddl_m_units selected idx do mrt_SmartDim_Logic.updateLiveDims #units
		on spn_m_text changed val do mrt_SmartDim_Logic.updateLiveDims #measure
		on spn_m_arrow changed val do mrt_SmartDim_Logic.updateLiveDims #measure
		on spn_m_offset changed val do mrt_SmartDim_Logic.updateLiveDims #measure
		on spn_m_txtOff changed val do mrt_SmartDim_Logic.updateLiveDims #measure
		on ddl_m_arrTyp selected idx do mrt_SmartDim_Logic.updateLiveDims #measure
		on cp_m_text changed col do mrt_SmartDim_Logic.updateLiveDims #measure
		on cp_m_line changed col do mrt_SmartDim_Logic.updateLiveDims #measure
		on btn_flip_m pressed do mrt_SmartDim_Logic.flipSelectedDims()

		on btn_clr pressed do undo "Clear Measurements" on (
			mrt_SmartDim_Logic.clearSectionDims "Measure"
		)

		on chk_measureDist changed state do (
			if state then (
				if mrt_SmartDim_Logic.checkBBoxInterference selection do (
					messageBox "Please use this measurement tool first, and apply 'Auto Bounding Box' as the final step.\nIf already applied, please Clear the Bounding Box first." title:"Workflow Order"
					chk_measureDist.checked = false
					return false
				)
				
				local oldSnapActive = snapMode.active
				local oldSnapType = snapMode.type
				
				try (
					snapMode.type = #3D
					snapMode.active = true
					
					try(setFocus (viewport.getHWND()))catch()
					
					local pt1 = pickPoint prompt:"Select First Point..." snap:#3D
					if classOf pt1 == Point3 do (
						local pt2 = pickPoint prompt:"Select Second Point..." snap:#3D rubberBand:pt1
						if classOf pt2 == Point3 do (
							local dist = distance pt1 pt2
							
							if dist > 0.0 do (
								local uIdx = if ddl_m_units.selection > 0 then ddl_m_units.selection else 1
								txt_distVal.text = mrt_SmartDim_Logic.formatValue dist uIdx
								
								local lineDir = normalize (pt2 - pt1)
								if length (pt2 - pt1) < 0.001 do lineDir = [1,0,0]
								
								local midPt = (pt1 + pt2) / 2.0
								local selObj = undefined
								local tHandle = 0
								
								if selection.count > 0 and isValidNode selection[1] then (
									selObj = selection[1]
									tHandle = selObj.handle
								) else if objects.count > 0 then (
									local minDist = 99999999.0
									for obj in objects where isValidNode obj do (
										if not obj.isHidden and not (isGroupHead obj and isProperty obj #IsSmartDim and obj.IsSmartDim) and not (obj.parent != undefined and isGroupHead obj.parent and isProperty obj.parent #IsSmartDim and obj.parent.IsSmartDim) do (
											local d = distance midPt obj.center
											if d < minDist do (
												minDist = d
												selObj = obj
												tHandle = obj.handle
											)
										)
									)
								)
								
								local outDir = cross lineDir [0,0,1]
								if length outDir < 0.001 do outDir = cross lineDir [1,0,0]
								outDir = normalize outDir
								
								if selObj != undefined and isValidNode selObj do (
									local toMid = midPt - selObj.center
									if (dot outDir toMid) < 0 do outDir = -outDir
								)
								
								mrt_SmartDim_isSelecting = true
								undo "Create Measurement" on (
									local createdGroup = mrt_SmartDim_Logic.createSmartDimLine pt1 pt2 outDir dist spn_m_arrow.value spn_m_text.value spn_m_offset.value cp_m_line.color cp_m_text.color "Measure" tHandle uIdx ddl_m_arrTyp.selection spn_m_txtOff.value
									select createdGroup
								)
								mrt_SmartDim_isSelecting = false
							)
						)
					)
				) catch (
					print "Measurement tool was interrupted."
				)
				
				snapMode.active = oldSnapActive
				snapMode.type = oldSnapType
				
				chk_measureDist.checked = false
			)
		)

		on btn_copy pressed do (
			if txt_distVal.text != "" do (
				setClipboardText txt_distVal.text
			)
		)
	)

	-- =========================================================================
	-- ROLLOUT 3: SMART OBJECTS DISTANCE
	-- =========================================================================
	rollout roll_smart_objects_distance "Smart Objects Distance" height:335 rolledUp:true
	(
		local l_bbox_obj1 = undefined
		local l_bbox_obj2 = undefined
		local l_bbox_dimGroupObj = undefined
		local l_bbox_textObj = undefined
		local l_bbox_lastP1 = [0,0,0]
		local l_bbox_lastP2 = [0,0,0]
		local l_bbox_lastRawDist = 0.0
		local l_bbox_lastLineDir = [1,0,0]
		local l_bbox_isFlipped = false

		local unitList = #("cm", "mm", "m", "in", "ft")

		fn getMaxVal v1 v2 = if v1 > v2 then v1 else v2

		fn getUnitScaleFactor targetUnit =
		(
			local sysScale = Units.SystemScale
			local sysType = Units.SystemType
			
			local inInches = case sysType of
			(
				#inches: sysScale
				#feet: sysScale * 12.0
				#miles: sysScale * 63360.0
				#millimeters: sysScale / 25.4
				#centimeters: sysScale / 2.54
				#meters: sysScale / 0.0254
				#kilometers: sysScale / 0.0000254
				default: sysScale
			)
			
			case targetUnit of
			(
				"mm": inInches * 25.4
				"cm": inInches * 2.54
				"m": inInches * 0.0254
				"in": inInches
				"ft": inInches / 12.0
				default: 1.0
			)
		)

		fn getMeshClosestPoints objA objB =
		(
			local geomA = #()
			local geomB = #()
			
			local stackA = #(objA)
			while stackA.count > 0 do (
				local n = stackA[stackA.count]
				stackA.count = stackA.count - 1
				if isGroupHead n then ( for c in n.children do append stackA c )
				else if superclassof n == GeometryClass do append geomA n
			)
			
			local stackB = #(objB)
			while stackB.count > 0 do (
				local n = stackB[stackB.count]
				stackB.count = stackB.count - 1
				if isGroupHead n then ( for c in n.children do append stackB c )
				else if superclassof n == GeometryClass do append geomB n
			)
			
			local minD = 1e9
			local bestP1 = objA.center
			local bestP2 = objB.center
			
			local meshesA = #()
			local meshesB = #()
			
			for ga in geomA where canConvertTo ga TriMeshGeometry do append meshesA (snapshotAsMesh ga)
			for gb in geomB where canConvertTo gb TriMeshGeometry do append meshesB (snapshotAsMesh gb)
			
			if meshesA.count == 0 or meshesB.count == 0 do (
				for m in meshesA do free m
				for m in meshesB do free m
				return #(bestP1, bestP2, distance bestP1 bestP2)
			)
			
			for m1 in meshesA do (
				for v1 = 1 to m1.numverts do (
					local vp1 = getVert m1 v1
					for m2 in meshesB do (
						for v2 = 1 to m2.numverts do (
							local vp2 = getVert m2 v2
							local d = distance vp1 vp2
							if d < minD do (
								minD = d
								bestP1 = vp1
								bestP2 = vp2
							)
						)
					)
				)
			)
			
			for m in meshesA do free m
			for m in meshesB do free m
			
			return #(bestP1, bestP2, minD)
		)

		fn getSmartAxisOrDiagonalPoints objA objB =
		(
			local baseData = getMeshClosestPoints objA objB
			local closestP1 = baseData[1]
			local closestP2 = baseData[2]
			local directDist = baseData[3]

			local finalP1 = closestP1
			local finalP2 = closestP2
			local finalDist = directDist
			local axisHitFound = false

			local testDirs = #([1,0,0], [-1,0,0], [0,1,0], [0,-1,0], [0,0,1], [0,0,-1])
			local minRayDist = 1e9
			local bestHitPos = [0,0,0]

			for dir in testDirs do
			(
				local testRay = ray closestP1 dir
				local hit = intersectRay objB testRay
				if hit != undefined do
				(
					local d = distance closestP1 hit.pos
					if d < minRayDist do
					(
						minRayDist = d
						bestHitPos = hit.pos
						axisHitFound = true
					)
				)
			)

			if axisHitFound then
			(
				finalP1 = closestP1
				finalP2 = bestHitPos
				finalDist = minRayDist
			)
			else
			(
				finalP1 = closestP1
				finalP2 = closestP2
				finalDist = directDist
			)

			return #(finalP1, finalP2, finalDist)
		)

		fn updateTextTransform customOffset =
		(
			if isValidNode l_bbox_textObj do
			(
				local baseDirX = normalize l_bbox_lastLineDir
				if baseDirX.x < 0 or (baseDirX.x == 0 and baseDirX.y < 0) do baseDirX = -baseDirX
				
				local upVec = [0,0,1]
				if (abs baseDirX.z) > 0.99 do upVec = [0,1,0]
				
				local sideDir = normalize (cross upVec baseDirX)
				local sideFactor = if l_bbox_isFlipped then -1.0 else 1.0
				local midP = (l_bbox_lastP1 + l_bbox_lastP2) * 0.5
				local textPos = midP + (sideDir * (customOffset * sideFactor))
				
				local dirX = baseDirX
				local dirY = sideDir
				local dirZ = normalize (cross dirX dirY)
				
				if l_bbox_isFlipped do
				(
					dirX = -dirX
					dirY = -dirY
				)
				
				l_bbox_textObj.transform = matrix3 dirX dirY dirZ textPos
			)
		)

		fn buildLineAndArrows p1 p2 arrowSize arrowType lineClr =
		(
			local groupNodes = #()
			local mainLine = splineShape name:(uniqueName "BBox_Line_")
			local mainSpline = addNewSpline mainLine
			
			local dir = normalize (p2 - p1)
			local cutLen = if arrowType == 2 then (arrowSize * 0.35) else if arrowType == 3 then arrowSize else 0.0
			local p1_line = p1 + dir * cutLen
			local p2_line = p2 - dir * cutLen
			
			addKnot mainLine mainSpline #corner #line p1_line
			addKnot mainLine mainSpline #corner #line p2_line
			updateShape mainLine
			
			if isProperty mainLine #render_renderable do mainLine.render_renderable = true
			if isProperty mainLine #render_displayInVP do mainLine.render_displayInVP = true
			if isProperty mainLine #render_thickness do mainLine.render_thickness = arrowSize * 0.08
			
			mainLine.wirecolor = lineClr
			append groupNodes mainLine

			local upVec = [0,0,1]
			if (abs dir.z) > 0.99 do upVec = [0,1,0]
			local sideVec = normalize (cross upVec dir)
			local planeNorm = normalize (cross dir sideVec)

			local a1 = mrt_SmartDim_Logic.createArrowMesh p1 dir planeNorm arrowSize arrowType lineClr
			local a2 = mrt_SmartDim_Logic.createArrowMesh p2 (-dir) planeNorm arrowSize arrowType lineClr
			
			if a1 != undefined do append groupNodes a1
			if a2 != undefined do append groupNodes a2

			return groupNodes
		)

		fn createOrUpdateMeasurement =
		(
			if not (isValidNode l_bbox_obj1 and isValidNode l_bbox_obj2) do return false

			local h1 = l_bbox_obj1.handle as string
			local h2 = l_bbox_obj2.handle as string
			for o in objects where (isValidNode o and isGroupHead o and isProperty o #IsSmartDim and o.IsSmartObjDim) do (
				local ph1 = o.Dim_ParentHandle
				local ph2 = o.Dim_ParentHandle2
				if (ph1 == h1 and ph2 == h2) or (ph1 == h2 and ph2 == h1) do delete o
			)

			local p1 = l_bbox_lastP1
			local p2 = l_bbox_lastP2
			local distVal = l_bbox_lastRawDist
			local lineLength = distance p1 p2
			if lineLength < 0.001 do return false

			local arrowSz = roll_smart_objects_distance.spnArrowSize.value
			local textSz = roll_smart_objects_distance.spnTextSize.value
			local textOffset = roll_smart_objects_distance.spnTextOffset.value
			local lineClr = roll_smart_objects_distance.cpLineColor.color
			local textClr = roll_smart_objects_distance.cpTextColor.color
			
			local selectedUnit = unitList[roll_smart_objects_distance.ddlUnit.selection]
			local arrowType = roll_smart_objects_distance.ddlArrowType.selection

			local lineAndArrowNodes = buildLineAndArrows p1 p2 arrowSz arrowType lineClr

			local scaleFactor = getUnitScaleFactor selectedUnit
			local convertedDist = distVal * scaleFactor
			local formattedText = (formattedPrint convertedDist format:".2f") + " " + selectedUnit

			l_bbox_textObj = text name:(uniqueName "BBox_Measure_Text_")
			l_bbox_textObj.text = formattedText
			l_bbox_textObj.size = textSz
			l_bbox_textObj.wirecolor = textClr

			updateTextTransform textOffset

			append lineAndArrowNodes l_bbox_textObj
			l_bbox_dimGroupObj = group lineAndArrowNodes name:(uniqueName "BBox_Measurement_")
			
			custAttributes.add l_bbox_dimGroupObj mrt_SmartDimData_CA
			l_bbox_dimGroupObj.IsSmartDim = true
			l_bbox_dimGroupObj.IsSmartObjDim = true
			if isValidNode l_bbox_obj1 do l_bbox_dimGroupObj.Dim_ParentHandle = (l_bbox_obj1.handle as string)
			if isValidNode l_bbox_obj2 do l_bbox_dimGroupObj.Dim_ParentHandle2 = (l_bbox_obj2.handle as string)
			
			select l_bbox_dimGroupObj
			return true
		)

		groupBox grpCreation "Creation" pos:[5,5] width:220 height:80
		button btnCalculate "Calculate Distance" pos:[15,25] width:100 height:24
		button btnClear "Clear" pos:[120,25] width:95 height:24
		button btnFlip "Flip Side" pos:[15,55] width:200 height:22
		
		groupBox grpSettings "Text & Unit Settings" pos:[5,90] width:220 height:155
		label lblTextSize "Text Size:" pos:[15,110] width:75 height:18
		spinner spnTextSize "" pos:[95,108] width:120 fieldwidth:65 range:[0.1, 1000.0, 7.5] type:#float scale:0.5
		
		label lblArrowSize "Marker Size:" pos:[15,135] width:75 height:18
		spinner spnArrowSize "" pos:[95,133] width:120 fieldwidth:65 range:[0.1, 1000.0, 5.0] type:#float scale:0.5
		
		label lblTextOffset "Text Offset:" pos:[15,160] width:75 height:18
		spinner spnTextOffset "" pos:[95,158] width:120 fieldwidth:65 range:[-1000.0, 1000.0, 7.5] type:#float scale:0.5
		
		label lblUnit "Unit:" pos:[15,185] width:75 height:18
		dropdownList ddlUnit "" pos:[95,183] width:120 items:unitList selection:1
		
		label lblArrowType "Marker Type:" pos:[15,210] width:75 height:18
		dropdownList ddlArrowType "" pos:[95,208] width:120 items:#("Open Arrow", "Solid Circle", "Filled Triangle", "None") selection:3
		
		groupBox grpColor "Color Customization" pos:[5,250] width:220 height:75
		colorpicker cpLineColor "Line Color:" pos:[15,268] width:130 height:22 color:(color 255 255 255)
		colorpicker cpTextColor "Text Color:" pos:[15,295] width:130 height:22 color:(color 255 255 255)

		on btnCalculate pressed do undo "Calculate Objects Distance" on
		(
			if mrt_SmartDim_Logic.checkBBoxInterference selection do (
				messageBox "Please use this measurement tool first, and apply 'Auto Bounding Box' as the final step.\nIf already applied, please Clear the Bounding Box first." title:"Workflow Order"
				return false
			)
			
			if selection.count == 2 then
			(
				l_bbox_obj1 = selection[1]
				l_bbox_obj2 = selection[2]
				
				local resultData = getSmartAxisOrDiagonalPoints l_bbox_obj1 l_bbox_obj2
				l_bbox_lastP1 = resultData[1]
				l_bbox_lastP2 = resultData[2]
				l_bbox_lastRawDist = resultData[3]
				l_bbox_lastLineDir = normalize (l_bbox_lastP2 - l_bbox_lastP1)
				l_bbox_isFlipped = false

				local lineLen = distance l_bbox_lastP1 l_bbox_lastP2
				local defaultArrow = getMaxVal (lineLen * 0.04) 1.0
				spnArrowSize.value = defaultArrow
				spnTextSize.value = defaultArrow * 1.5
				spnTextOffset.value = defaultArrow * 1.5

				if not createOrUpdateMeasurement() do
				(
					messageBox "Objects are touching or overlapping." title:"Zero Distance"
				)
			)
			else if selection.count > 2 then
			(
				local objs = for o in selection collect o
				local processedPairs = #()
				local pairsToDraw = #()
				local avgDist = 0.0
				
				for i = 1 to objs.count do (
					local objA = objs[i]
					local minD = 1e9
					local closestObj = undefined
					for j = 1 to objs.count do (
						if i != j do (
							local objB = objs[j]
							local d = distance objA.center objB.center
							if d < minD do (
								minD = d
								closestObj = objB
							)
						)
					)
					if closestObj != undefined do (
						local hA = objA.handle as string
						local hB = closestObj.handle as string
						local pairKey1 = hA + "_" + hB
						local pairKey2 = hB + "_" + hA
						if (findItem processedPairs pairKey1) == 0 and (findItem processedPairs pairKey2) == 0 do (
							append processedPairs pairKey1
							append processedPairs pairKey2
							append pairsToDraw #(objA, closestObj)
							avgDist += minD
						)
					)
				)
				
				if pairsToDraw.count > 0 do (
					avgDist = avgDist / pairsToDraw.count
					local defaultArrow = getMaxVal (avgDist * 0.04) 1.0
					spnArrowSize.value = defaultArrow
					spnTextSize.value = defaultArrow * 1.5
					spnTextOffset.value = defaultArrow * 1.5
					
					local createdGroups = #()
					for p in pairsToDraw do (
						l_bbox_obj1 = p[1]
						l_bbox_obj2 = p[2]
						local resultData = getSmartAxisOrDiagonalPoints l_bbox_obj1 l_bbox_obj2
						l_bbox_lastP1 = resultData[1]
						l_bbox_lastP2 = resultData[2]
						l_bbox_lastRawDist = resultData[3]
						l_bbox_lastLineDir = normalize (l_bbox_lastP2 - l_bbox_lastP1)
						l_bbox_isFlipped = false
						
						l_bbox_dimGroupObj = undefined 
						
						if createOrUpdateMeasurement() do (
							append createdGroups l_bbox_dimGroupObj
						)
					)
					if createdGroups.count > 0 do select createdGroups
				)
			)
			else
			(
				messageBox "Please select 2 or more objects." title:"Selection Error"
			)
		)

		on btnClear pressed do undo "Clear Distance" on (
			mrt_SmartDim_Logic.clearSectionDims "SmartObj"
		)

		on btnFlip pressed do
		(
			l_bbox_isFlipped = not l_bbox_isFlipped
			if isValidNode l_bbox_textObj do
			(
				updateTextTransform spnTextOffset.value
			)
		)

		on spnArrowSize changed val do undo off ( createOrUpdateMeasurement() )
		on spnTextSize changed val do undo off ( createOrUpdateMeasurement() )
		on spnTextOffset changed val do undo off (
			if isValidNode l_bbox_textObj do ( updateTextTransform val )
		)
		on cpLineColor changed clr do undo off ( createOrUpdateMeasurement() )
		on cpTextColor changed clr do undo off ( createOrUpdateMeasurement() )
		on ddlUnit selected idx do undo off ( createOrUpdateMeasurement() )
		on ddlArrowType selected idx do undo off ( createOrUpdateMeasurement() )
	)

	-- =========================================================================
	-- ROLLOUT 4:  MEASURE ANGLE
	-- =========================================================================
	rollout mrt_SmartDim_Angle "Measure Angle" height:380 rolledUp:true
	(
		radiobuttons rdo_mode "Mode:" labels:#("Single (3 Pts)", "Multi (Continuous)") default:1 pos:[12,10]
		checkbutton btn_start "Start Measure" pos:[12,65] width:100 height:25 highlightColor:(color 0 150 255)
		button btn_clear "Clear" pos:[118,65] width:100 height:25
		checkbutton btn_helper "Create Helper Point" pos:[12,95] width:206 height:22 highlightColor:(color 30 144 255)
		
		groupBox grpStyle "Style & Sizes" pos:[5,125] width:220 height:125
		label lblArrowType "Marker Type:" pos:[15,145] width:75 height:18
		dropdownlist ddl_arrowType "" pos:[95,143] width:120 items:#("Open Arrow", "Solid Circle", "Filled Triangle", "None") selection:3
		
		label lblArrowSize "Marker Size:" pos:[15,170] width:75 height:18
		spinner spn_arrowScale "" pos:[95,168] width:120 fieldwidth:65 range:[0.1, 1000.0, 1.0] scale:0.05 type:#float
		
		label lblTextSize "Degree Size:" pos:[15,195] width:75 height:18
		spinner spn_textSize "" pos:[95,193] width:120 fieldwidth:65 range:[0.1, 1000.0, 1.0] scale:0.05 type:#float
		
		label lblTextOffset "Text Offset:" pos:[15,220] width:75 height:18
		spinner spn_textOffset "" pos:[95,218] width:120 fieldwidth:65 range:[-1000.0, 1000.0, 0.0] scale:0.5 type:#float
		
		groupBox grpCol "Colors" pos:[5,260] width:220 height:75
		colorpicker cp_line "Line/Arrow Color:" pos:[15,278] width:140 height:22 color:(color 255 255 255)
		colorpicker cp_text "Degree Color:" pos:[15,305] width:140 height:22 color:(color 255 255 255)
		
		label lbl_angle "Degree: ---" pos:[12,345] width:206 height:20 style_sunkenedges:true

		fn calcAngle p1 p2 p3 =
		(
			local v1 = normalize (p1 - p2)
			local v2 = normalize (p3 - p2)
			local d = dot v1 v2
			d = amin 1.0 (amax -1.0 d)
			return acos d
		)

		fn addAngleArc sp centerPt v1 v2 normVec arcRadius steps:24 =
		(
			local arcIdx = addNewSpline sp
			local totalAngle = acos (amin 1.0 (amax -1.0 (dot v1 v2)))
			local perpVec = normalize (cross normVec v1)
			if (dot perpVec v2) < 0 do perpVec = -perpVec
			
			for i = 0 to steps do
			(
				local t = (i as float) / steps
				local currentAng = totalAngle * t
				local dir = (v1 * cos currentAng) + (perpVec * sin currentAng)
				local pt = centerPt + (dir * arcRadius)
				addKnot sp arcIdx #smooth #curve pt
			)
		)

		fn createSingleAngle p1 p2 p3 lineClr textClr arrScale txtScale txtOff arrType pHandle isFirst:true isLast:true =
		(
			local groupObjects = #()
			local ang = calcAngle p1 p2 p3
			local strAngle = (formattedPrint ang format:".1f") + "�"
			
			local d1 = distance p1 p2
			local d2 = distance p3 p2
			local avgRadius = (d1 + d2) / 2.0
			
			local v1 = normalize (p1 - p2)
			local v2 = normalize (p3 - p2)
			
			local normVec = normalize (cross v1 v2)
			if length normVec == 0 do normVec = [0, 0, 1]
			
			local camTM = inverse (viewport.getTM())
			local camUp = normalize camTM.row2
			local camDir = normalize camTM.row3
			
			if (dot normVec camDir) < 0 do normVec = -normVec
			
			local safeOffsetDist = avgRadius * 0.05
			local offsetVec = normVec * safeOffsetDist
			
			local pt1 = p1 + offsetVec
			local pt2 = p2 + offsetVec
			local pt3 = p3 + offsetVec
			
			local sp = SplineShape name:(uniqueName "Angle_Line") wirecolor:lineClr
			
			local mainIdx = addNewSpline sp
			
			local baseArrowLen = avgRadius * 0.05
			local arrowLen = baseArrowLen * arrScale
			local cutLen = if arrType == 2 then (arrowLen * 0.35) else if arrType == 3 then arrowLen else 0.0
			
			local pt1_line = if isFirst then (pt1 + (normalize(pt2 - pt1)) * cutLen) else pt1
			local pt3_line = if isLast then (pt3 + (normalize(pt2 - pt3)) * cutLen) else pt3
			
			addKnot sp mainIdx #corner #line pt1_line
			addKnot sp mainIdx #corner #line pt2
			addKnot sp mainIdx #corner #line pt3_line
			
			if arrType != 4 do
			(
				if isFirst do (
					local a1 = mrt_SmartDim_Logic.createArrowMesh pt1 (normalize(pt2 - pt1)) normVec arrowLen arrType lineClr
					if a1 != undefined do append groupObjects a1
				)
				if isLast do (
					local a2 = mrt_SmartDim_Logic.createArrowMesh pt3 (normalize(pt2 - pt3)) normVec arrowLen arrType lineClr
					if a2 != undefined do append groupObjects a2
				)
			)
			
			local arcRadius = avgRadius * 0.22
			addAngleArc sp pt2 v1 v2 normVec arcRadius
			
			updateShape sp
			append groupObjects sp
			
			local bisectorVec = normalize (v1 + v2)
			local textPos = pt2 + (bisectorVec * ((avgRadius * 0.38) + txtOff))
			
			local textX = normalize (v1 - v2)
			textX = normalize (textX - normVec * (dot textX normVec))
			local textY = normalize (cross normVec textX)
			
			if (dot textY camUp) < -0.01 do
			(
				textX = -textX
				textY = -textY
			)
			
			if (abs (dot textY camUp) < 0.2) and ((dot textX camUp) < 0) do
			(
				textX = -textX
				textY = -textY
			)
			
			local alignMatrix = matrix3 textX textY normVec textPos
			local baseTextSize = avgRadius * 0.08
			local calculatedSize = baseTextSize * txtScale
			
			local angleTextObj = text name:(uniqueName "Angle_Value_Text") wirecolor:textClr
			angleTextObj.size = calculatedSize
			angleTextObj.text = strAngle
			angleTextObj.transform = alignMatrix
			append groupObjects angleTextObj
			
			local newGrp = group groupObjects name:(uniqueName "Angle_Measure_Group")
			
			custAttributes.add newGrp mrt_SmartDimData_CA
			newGrp.IsSmartDim = true
			newGrp.IsAngleDim = true
			newGrp.Ang_RawP1 = p1
			newGrp.Ang_RawP2 = p2
			newGrp.Ang_RawP3 = p3
			newGrp.Ang_IsFirst = isFirst
			newGrp.Ang_IsLast = isLast
			if pHandle != undefined do newGrp.Dim_ParentHandle = pHandle
			
			return newGrp
		)

		fn updateLiveAngleDims =
		(
			local selGroups = for obj in selection where (isGroupHead obj or (obj.parent != undefined and isGroupHead obj.parent)) collect (if isGroupHead obj then obj else obj.parent)
			local uniqueGroups = #()
			for g in selGroups do if findItem uniqueGroups g == 0 do append uniqueGroups g
			
			if uniqueGroups.count == 0 do
			(
				uniqueGroups = for o in objects where (isGroupHead o and isProperty o #IsSmartDim and o.IsAngleDim) collect o
			)
			
			if uniqueGroups.count == 0 do return false
			
			local newSel = #()
			
			with undo off (
				with redraw off
				(
					for grp in uniqueGroups do
					(
						if isProperty grp #IsSmartDim and grp.IsAngleDim do
						(
							local p1 = grp.Ang_RawP1
							local p2 = grp.Ang_RawP2
							local p3 = grp.Ang_RawP3
							local isFirst = grp.Ang_IsFirst
							local isLast = grp.Ang_IsLast
							local pHStr = grp.Dim_ParentHandle
							local pHandle = if pHStr != "" then pHStr as string else undefined
							
							if p1 != undefined and p2 != undefined and p3 != undefined do
							(
								delete grp
								local newG = createSingleAngle p1 p2 p3 mrt_SmartDim_Angle.cp_line.color mrt_SmartDim_Angle.cp_text.color mrt_SmartDim_Angle.spn_arrowScale.value mrt_SmartDim_Angle.spn_textSize.value mrt_SmartDim_Angle.spn_textOffset.value mrt_SmartDim_Angle.ddl_arrowType.selection pHandle isFirst:isFirst isLast:isLast
								append newSel newG
							)
						)
					)
					if newSel.count > 0 do select newSel
				)
			)
			redrawViews()
		)

		on spn_arrowScale changed val do updateLiveAngleDims()
		on spn_textSize changed val do updateLiveAngleDims()
		on spn_textOffset changed val do updateLiveAngleDims()
		on ddl_arrowType selected sel do updateLiveAngleDims()
		on cp_line changed clr do updateLiveAngleDims()
		on cp_text changed clr do updateLiveAngleDims()

		on btn_clear pressed do undo "Clear Angle" on (
			mrt_SmartDim_Logic.clearSectionDims "Angle"
			lbl_angle.text = "Degree: ---"
		)

		on btn_helper changed state do
		(
			if state then
			(
				local oldSnapActive = snapMode.active
				local oldSnapType = snapMode.type
				try (
					snapMode.type = #3D
					snapMode.active = true
					local ptPos = pickPoint prompt:"Click to place Helper Point:" snap:#3D
					if classOf ptPos == Point3 do
					(
						local hp = Point pos:ptPos size:(spn_arrowScale.value * 10.0) box:true cross:true wirecolor:(color 0 255 255) name:(uniqueName "Angle_HelperPoint")
						select hp
					)
				) catch (
					print "Helper point placement interrupted."
				)
				snapMode.type = oldSnapType
				snapMode.active = oldSnapActive
				btn_helper.checked = false
			)
		)

		on btn_start changed state do
		(
			if state then
			(
				if mrt_SmartDim_Logic.checkBBoxInterference selection do (
					messageBox "Please use this measurement tool first, and apply 'Auto Bounding Box' as the final step.\nIf already applied, please Clear the Bounding Box first." title:"Workflow Order"
					btn_start.checked = false
					return false
				)
				
				local prevSnapActive = snapMode.active
				local prevSnapType = snapMode.type
				local savedOSnapStates = #()
				
				try
				(
					for i = 1 to snapMode.numOSnaps do
					(
						local subStates = #()
						for j = 1 to (snapMode.getOSnapNumItems i) do
						(
							append subStates (snapMode.getOSnapItemActive i j)
							local itemName = snapMode.getOSnapItemName i j
							if (matchPattern itemName pattern:"*Vertex*" ignoreCase:true) then
								snapMode.setOSnapItemActive i j true
							else
								snapMode.setOSnapItemActive i j false
						)
						append savedOSnapStates subStates
					)
				
					snapMode.type = #3D
					snapMode.active = true
					
					local lineC = cp_line.color
					local textC = cp_text.color
					local aScale = spn_arrowScale.value
					local tScale = spn_textSize.value
					local tOff = spn_textOffset.value
					local aType = ddl_arrowType.selection
					
					local sObj = if selection.count > 0 then selection[1] else undefined
					local pHandle = if isValidNode sObj then (sObj.handle as string) else undefined
					
					undo "Measure Angle" on
					(
						if rdo_mode.state == 1 then
						(
							local p1 = pickPoint prompt:"[1/3] Select First Point:" snap:#3D
							if classOf p1 == Point3 do
							(
								local p2 = pickPoint prompt:"[2/3] Select Corner Vertex (p2):" snap:#3D rubberBand:p1
								if classOf p2 == Point3 do
								(
									local p3 = pickPoint prompt:"[3/3] Select Third Point:" snap:#3D rubberBand:p2
									if classOf p3 == Point3 do
									(
										local newGrp = createSingleAngle p1 p2 p3 lineC textC aScale tScale tOff aType pHandle isFirst:true isLast:true
										local angVal = calcAngle p1 p2 p3
										lbl_angle.text = "Degree: " + ((formattedPrint angVal format:".1f") + "�")
										select newGrp
									)
								)
							)
						)
						else
						(
							local pointsList = #()
							local pFirst = pickPoint prompt:"Select Point 1 (ESC to Exit):" snap:#3D
							if classOf pFirst == Point3 do
							(
								append pointsList pFirst
								local pSecond = pickPoint prompt:"Select Corner Vertex p2 (ESC to Exit):" snap:#3D rubberBand:pFirst
								if classOf pSecond == Point3 do
								(
									append pointsList pSecond
									local continueLoop = true
									while continueLoop do
									(
										local lastPt = pointsList[pointsList.count]
										local pNext = pickPoint prompt:"Select Next Point (ESC to Finish):" snap:#3D rubberBand:lastPt
										if pNext == #escape or classOf pNext != Point3 then
										(
											continueLoop = false
										)
										else
										(
											append pointsList pNext
										)
									)
									
									if pointsList.count >= 3 do
									(
										local createdMultiGroups = #()
										for i = 1 to (pointsList.count - 2) do
										(
											local ptA = pointsList[i]
											local ptB = pointsList[i+1]
											local ptC = pointsList[i+2]
											
											local isFirstSeg = (i == 1)
											local isLastSeg = (i == pointsList.count - 2)
											
											local grp = createSingleAngle ptA ptB ptC lineC textC aScale tScale tOff aType pHandle isFirst:isFirstSeg isLast:isLastSeg
											append createdMultiGroups grp
											
											local angVal = calcAngle ptA ptB ptC
											lbl_angle.text = "Last Degree: " + ((formattedPrint angVal format:".1f") + "�")
										)
										if createdMultiGroups.count > 0 do select createdMultiGroups
									)
								)
							)
						)
					)
				) catch (
					print "Angle measure tool interrupted."
				)
				
				try
				(
					for i = 1 to savedOSnapStates.count do
						for j = 1 to savedOSnapStates[i].count do
							snapMode.setOSnapItemActive i j savedOSnapStates[i][j]
				) catch ()
				
				snapMode.type = prevSnapType
				snapMode.active = prevSnapActive
				
				btn_start.checked = false
			)
		)
	)

	-- =========================================================================
	-- ROLLOUT 5: AREA & PERIMETER
	-- =========================================================================
	rollout roll_area_peri_tool "Area & Perimeter Tool" height:300 rolledUp:true
	(
		local prevSnapActive = snapMode.active
		local prevSnapType = snapMode.type
		local savedOSnapStates = #()
		
		local currentSpline = undefined
		local currentTextArea = undefined
		local currentTextPeri = undefined
		local currentGroup = undefined
		
		local rawAreaVal = 0.0
		local rawPeriVal = 0.0
		
		local unitList = #("cm", "mm", "m", "in", "ft")
		
		fn getUnitScaleFactor targetUnit =
		(
			local sysScale = Units.SystemScale
			local sysType = Units.SystemType
			
			local inInches = case sysType of
			(
				#inches: sysScale
				#feet: sysScale * 12.0
				#miles: sysScale * 63360.0
				#millimeters: sysScale / 25.4
				#centimeters: sysScale / 2.54
				#meters: sysScale / 0.0254
				#kilometers: sysScale / 0.0000254
				default: sysScale
			)
			
			case targetUnit of
			(
				"mm": inInches * 25.4
				"cm": inInches * 2.54
				"m": inInches * 0.0254
				"in": inInches
				"ft": inInches / 12.0
				default: 1.0
			)
		)

		fn calculate3DArea pointsList =
		(
			local numPts = pointsList.count
			if numPts < 3 do return 0.0
			
			local normalVec = [0,0,0]
			for i = 1 to numPts do
			(
				local currentPt = pointsList[i]
				local nextPt = pointsList[(mod i numPts as integer) + 1]
				normalVec += cross currentPt nextPt
			)
			return (length normalVec) * 0.5
		)

		fn calculatePerimeter pointsList =
		(
			local numPts = pointsList.count
			if numPts < 2 do return 0.0
			
			local totalLength = 0.0
			for i = 1 to numPts do
			(
				local currentPt = pointsList[i]
				local nextPt = pointsList[(mod i numPts as integer) + 1]
				totalLength += distance currentPt nextPt
			)
			return totalLength
		)

		groupBox grpCreation "Creation" pos:[5,5] width:220 height:60
		checkbutton btn_start "Measure Area & Peri" pos:[15,25] width:125 height:24 highlightColor:(color 0 150 255)
		button btn_clear "Clear" pos:[145,25] width:70 height:24
		
		groupBox grpSettings "Text & Unit Settings" pos:[5,75] width:220 height:130
		label lblTextSize "Text Size:" pos:[15,90] width:75 height:18
		spinner spn_textSize "" pos:[95,88] width:120 fieldwidth:65 range:[0.1, 1000.0, 5.0] type:#float scale:0.5
		
		label lblTextOffset "Text Gap:" pos:[15,115] width:75 height:18
		spinner spn_textOffset "" pos:[95,113] width:120 fieldwidth:65 range:[-1000.0, 1000.0, 0.0] type:#float scale:0.5
		
		label lblOffsetDist "Surf Offset:" pos:[15,140] width:75 height:18
		spinner spn_offsetDist "" pos:[95,138] width:120 fieldwidth:65 range:[-1000.0, 1000.0, 1.0] type:#float scale:0.5
		
		label lblUnit "Unit:" pos:[15,165] width:75 height:18
		dropdownList ddl_units "" pos:[95,163] width:120 items:unitList selection:1
		
		groupBox grpColor "Color Customization" pos:[5,215] width:220 height:75
		colorpicker cp_lineColor "Line Color:" pos:[15,233] width:140 height:22 color:(color 255 255 255)
		colorpicker cp_textColor "Text Color:" pos:[15,260] width:140 height:22 color:(color 255 255 255)

		on spn_textSize changed val do
		(
			if isValidNode currentTextArea and isValidNode currentTextPeri do
			(
				currentTextArea.size = val
				currentTextPeri.size = val
				
				local localOffset = [0, (val * 1.4) + spn_textOffset.value, 0]
				currentTextArea.transform = in coordsys currentTextPeri.transform (transMatrix localOffset) * currentTextPeri.transform
			)
		)

		on spn_textOffset changed val do
		(
			if isValidNode currentTextArea and isValidNode currentTextPeri do
			(
				local txtS = spn_textSize.value
				local localOffset = [0, (txtS * 1.4) + val, 0]
				currentTextArea.transform = in coordsys currentTextPeri.transform (transMatrix localOffset) * currentTextPeri.transform
			)
		)

		on spn_offsetDist changed val do
		(
			-- Only apply dynamically if required, mostly for new creations
		)

		on ddl_units selected idx do
		(
			local selectedUnit = unitList[idx]
			local scaleFactor = getUnitScaleFactor selectedUnit
			
			if isValidNode currentTextArea and isValidNode currentTextPeri do
			(
				local convertedPeri = rawPeriVal * scaleFactor
				local convertedArea = rawAreaVal * (scaleFactor * scaleFactor)
				
				currentTextArea.text = "Area: " + (formattedPrint convertedArea format:".2f") + " " + selectedUnit + "�"
				currentTextPeri.text = "Perimeter: " + (formattedPrint convertedPeri format:".2f") + " " + selectedUnit
			)
		)

		on cp_lineColor changed newCol do
		(
			if isValidNode currentSpline do currentSpline.wirecolor = newCol
		)

		on cp_textColor changed newCol do
		(
			if isValidNode currentTextArea do currentTextArea.wirecolor = newCol
			if isValidNode currentTextPeri do currentTextPeri.wirecolor = newCol
		)
		
		on btn_clear pressed do undo "Clear Area" on (
			mrt_SmartDim_Logic.clearSectionDims "Area"
		)

		on btn_start changed state do
		(
			if state then
			(
				if mrt_SmartDim_Logic.checkBBoxInterference selection do (
					messageBox "Please use this measurement tool first, and apply 'Auto Bounding Box' as the final step.\nIf already applied, please Clear the Bounding Box first." title:"Workflow Order"
					btn_start.checked = false
					return false
				)
				
				prevSnapActive = snapMode.active
				prevSnapType = snapMode.type
				savedOSnapStates = #()
				
				try
				(
					for i = 1 to snapMode.numOSnaps do
					(
						local subStates = #()
						for j = 1 to (snapMode.getOSnapNumItems i) do
						(
							append subStates (snapMode.getOSnapItemActive i j)
							local itemName = snapMode.getOSnapItemName i j
							if (matchPattern itemName pattern:"*Vertex*" ignoreCase:true) then
								snapMode.setOSnapItemActive i j true
							else
								snapMode.setOSnapItemActive i j false
						)
						append savedOSnapStates subStates
					)
				
					snapMode.active = true
					snapMode.type = #3D

					local collectedPoints = #()
					local isClosed = false
					
					local firstPt = pickPoint prompt:"Click starting vertex..." snap:#3D
					
					if firstPt != undefined and firstPt != #rightClick then
					(
						append collectedPoints firstPt
						
						while not isClosed do
						(
							local nextPt = pickPoint prompt:"Click next vertex (Click Start Vertex to Close)..." snap:#3D rubberBand:collectedPoints[collectedPoints.count]
							
							if nextPt == #rightClick or nextPt == undefined then exit
							
							local distToFirst = distance nextPt firstPt
							
							if distToFirst < 10.0 and collectedPoints.count >= 3 then
							(
								isClosed = true
							)
							else
							(
								append collectedPoints nextPt
							)
						)
						
						if isClosed and collectedPoints.count >= 3 then
						(
							undo "Measure Area" on (
								local vecA = normalize (collectedPoints[2] - collectedPoints[1])
								local vecB = normalize (collectedPoints[3] - collectedPoints[1])
								local planeNormal = normalize (cross vecA vecB)
								if (length planeNormal) == 0 do planeNormal = [0,0,1]
								
								local camTM = inverse (viewport.getTM())
								local camDir = normalize camTM.row3
								if (dot planeNormal camDir) < 0 do planeNormal = -planeNormal
								
								local safeDistance = spn_offsetDist.value
								local offsetVector = planeNormal * safeDistance
								
								currentSpline = splineShape name:(uniqueName "Measured_Polygon_")
								currentSpline.wirecolor = cp_lineColor.color
								addNewSpline currentSpline
								for pt in collectedPoints do addKnot currentSpline 1 #corner #line (pt + offsetVector)
								close currentSpline 1
								updateShape currentSpline
								
								rawAreaVal = calculate3DArea collectedPoints
								rawPeriVal = calculatePerimeter collectedPoints
								
								local selectedUnit = unitList[ddl_units.selection]
								local scaleFactor = getUnitScaleFactor selectedUnit
								
								local convertedPeri = rawPeriVal * scaleFactor
								local convertedArea = rawAreaVal * (scaleFactor * scaleFactor)
								
								local areaFormatted = formattedPrint convertedArea format:".2f"
								local periFormatted = formattedPrint convertedPeri format:".2f"
								
								local centerPos = [0,0,0]
								for pt in collectedPoints do centerPos += pt
								centerPos /= collectedPoints.count
								centerPos += offsetVector
								
								local vecZ = planeNormal
								local vecX = normalize (collectedPoints[2] - collectedPoints[1])
								vecX = normalize (vecX - vecZ * (dot vecX vecZ))
								local vecY = normalize (cross vecZ vecX)
								
								local camUp = normalize camTM.row2
								if (dot vecY camUp) < -0.01 do
								(
									vecX = -vecX
									vecY = -vecY
								)
								if (abs(dot vecY camUp) < 0.2) and ((dot vecX camUp) < 0) do
								(
									vecX = -vecX
									vecY = -vecY
								)
								
								local alignTM = matrix3 vecX vecY vecZ centerPos
								
								local initialSize = rawPeriVal / 45.0
								if initialSize < 0.5 do initialSize = 0.5
								spn_textSize.value = initialSize
								local txtOff = spn_textOffset.value
								
								currentTextPeri = text name:(uniqueName "Text_Perimeter_")
								currentTextPeri.text = "Perimeter: " + periFormatted + " " + selectedUnit
								currentTextPeri.size = initialSize
								currentTextPeri.wirecolor = cp_textColor.color
								currentTextPeri.transform = alignTM
								
								currentTextArea = text name:(uniqueName "Text_Area_")
								currentTextArea.text = "Area: " + areaFormatted + " " + selectedUnit + "�"
								currentTextArea.size = initialSize
								currentTextArea.wirecolor = cp_textColor.color
								currentTextArea.transform = alignTM
								
								in coordsys local move currentTextArea [0, (initialSize * 1.4) + txtOff, 0]
								
								currentGroup = group #(currentSpline, currentTextArea, currentTextPeri) name:(uniqueName "Measurement_Group_")
								
								custAttributes.add currentGroup mrt_SmartDimData_CA
								currentGroup.IsSmartDim = true
								currentGroup.IsAreaDim = true
								
								local sObj = if selection.count > 0 then selection[1] else undefined
								if isValidNode sObj do currentGroup.Dim_ParentHandle = (sObj.handle as string)
								
								select currentGroup
							)
						)
					)
				) catch (
					print "Area measure tool interrupted."
				)
				
				try
				(
					for i = 1 to savedOSnapStates.count do
						for j = 1 to savedOSnapStates[i].count do
							snapMode.setOSnapItemActive i j savedOSnapStates[i][j]
				) catch ()
				
				snapMode.type = prevSnapType
				snapMode.active = prevSnapActive
				
				btn_start.checked = false
			)
		)
	)

	-- =========================================================================
	-- ROLLOUT 6: ABOUT / METADATA
	-- =========================================================================
	rollout mrt_SmartDim_About "About" rolledUp:true
	(
		label lbl_copyright "Copyright (c) 2026" pos:[55,10]
		label lbl_name "Mohammad Reza Taheri" pos:[45,25]
		label lbl_email "mrt.visual@gmail.com" pos:[50,40]
		label lbl_padding "" pos:[10,55] height:5
	)

	-- =========================================================================
	-- MAIN PARENT ROLLOUT & DOCKING LOGIC
	-- =========================================================================
	rollout mrt_SmartDim_Main "Smart Dimensions" width:250 height:820
	(
		button btnDockLeft "<" width:22 height:16 align:#left Across:3 offset:[0,-2] flat:true
		label lblTitle "Smart Dimensions" align:#center offset:[0, -1]
		button btnDockRight ">" width:22 height:16 align:#right offset:[0,-2] flat:true
		
		subRollout subRoll "" width:235 height:785 align:#center offset:[0,5]
		
		on mrt_SmartDim_Main open do (
			AddSubRollout mrt_SmartDim_Main.subRoll mrt_SmartDim_TopBar
			AddSubRollout mrt_SmartDim_Main.subRoll mrt_SmartDim_BBox
			AddSubRollout mrt_SmartDim_Main.subRoll mrt_SmartDim_Measure
			AddSubRollout mrt_SmartDim_Main.subRoll roll_smart_objects_distance
			AddSubRollout mrt_SmartDim_Main.subRoll mrt_SmartDim_Angle
			AddSubRollout mrt_SmartDim_Main.subRoll roll_area_peri_tool
			AddSubRollout mrt_SmartDim_Main.subRoll mrt_SmartDim_About
			
			callbacks.removeScripts id:#SmartDimAutoSelect
			callbacks.addScript #selectionSetChanged "cb_SmartDimAutoSelect()" id:#SmartDimAutoSelect
		)
		
		on mrt_SmartDim_Main resized size do (
			subRoll.width = size.x - 15
			subRoll.height = size.y - 35
		)
		
		on btnDockLeft pressed do (
			cui.dockDialogBar mrt_SmartDim_Main #cui_dock_left
			setINISetting iniFile "DockSettings" "State" "cui_dock_left"
		)
		
		on btnDockRight pressed do (
			cui.dockDialogBar mrt_SmartDim_Main #cui_dock_right
			setINISetting iniFile "DockSettings" "State" "cui_dock_right"
		)
		
		on mrt_SmartDim_Main close do (
			try (
				local ds = cui.getDockState mrt_SmartDim_Main
				if ds != undefined and ds != "" do setINISetting iniFile "DockSettings" "State" (ds as string)
			) catch ()
			callbacks.removeScripts id:#SmartDimAutoSelect
		)
	)

	on isChecked return (mrt_SmartDim_Main != undefined and mrt_SmartDim_Main.open)
	
	on execute do (
		if (mrt_SmartDim_Main != undefined and mrt_SmartDim_Main.open) then (
			try(cui.unRegisterDialogBar mrt_SmartDim_Main)catch()
			try(destroyDialog mrt_SmartDim_Main)catch()
		) else (
			try(cui.unRegisterDialogBar mrt_SmartDim_Main)catch()
			try(destroyDialog mrt_SmartDim_Main)catch()
			
			createDialog mrt_SmartDim_Main style:#(#style_border, #style_resizing, #style_sysmenu) width:250 height:820
			cui.registerDialogBar mrt_SmartDim_Main minSize:[250,400] maxSize:[250,1000] style:#(#cui_dock_left, #cui_dock_right, #cui_floatable)
			
			local savedState = getINISetting iniFile "DockSettings" "State"
			if savedState != "" then (
				case savedState of (
					"cui_dock_left": cui.dockDialogBar mrt_SmartDim_Main #cui_dock_left
					"cui_dock_right": cui.dockDialogBar mrt_SmartDim_Main #cui_dock_right
					default: cui.floatDialogBar mrt_SmartDim_Main
				)
			) else cui.floatDialogBar mrt_SmartDim_Main
		)
	)
)